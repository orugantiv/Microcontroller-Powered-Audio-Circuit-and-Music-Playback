#include "mbed.h"

#include <iostream>
class pinVol {
public:
//    pinVol(PinName pin,int pinVolume, int& volumeLevel) : _interrupt(pin),_currentLevel(pinVolume),_volumeLevel(&volumeLevel) {       
//        _interrupt.rise(this, &pinVol::setVolume);
//    }
//    void setVolume() {
//        *_volumeLevel = _currentLevel;
//        //std::cout<<_currentLevel<<std::endl;
//    } 
//    InterruptIn _interrupt;
//
//private:
//    int* _volumeLevel;
//    int _currentLevel;
};